// AddNew.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "DataSQL.h"
#include "AddNew.h"


// CAddNew

IMPLEMENT_DYNAMIC(CAddNew, CWnd)

CAddNew::CAddNew()
{

}

CAddNew::~CAddNew()
{
}


BEGIN_MESSAGE_MAP(CAddNew, CWnd)
END_MESSAGE_MAP()



// CAddNew ��Ϣ��������


