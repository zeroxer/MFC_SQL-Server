#pragma once


// CAddNew

class CAddNew : public CWnd
{
	DECLARE_DYNAMIC(CAddNew)

public:
	CAddNew();
	virtual ~CAddNew();

protected:
	DECLARE_MESSAGE_MAP()
};


